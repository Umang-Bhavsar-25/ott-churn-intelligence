# OTT Churn Intelligence — Python Website

## Run locally
1. Install Python 3.10+ and unzip this project.
2. Open a terminal in this folder.
3. Create and activate a virtual environment (optional but recommended).
4. Run `pip install -r requirements.txt`.
5. Run `streamlit run app.py`.
6. Open the local URL printed in the terminal (normally http://localhost:8501).

The package includes `ott_customers.csv` (10,000 synthetic demo records), `churn_model.joblib`, and the Streamlit dashboard.

## Google Colab
Open `OTT_Churn_Intelligence_Jupyter_Notebook.ipynb` and run cells top to bottom. The notebook installs dependencies in the Colab runtime, regenerates the data/model/app, and launches the app using Colab port forwarding.

## Important
This is a student demonstration using synthetic data, not real customer records from Netflix, Prime Video, or Disney+ Hotstar. Model scores are educational and should not be used for real customer decisions without validation on authorized real data.
