from pathlib import Path
from datetime import datetime
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import joblib

st.set_page_config(page_title="OTT Churn Intelligence",page_icon="🎬",layout="wide")
ROOT=Path(__file__).parent
DATA=ROOT/"ott_customers.csv"
MODEL=ROOT/"churn_model.joblib"
FEATURES=["age","gender","subscription_plan","monthly_charges","watch_hours_week","favorite_genre",
"logins_per_week","days_since_last_active","payment_delay_days","devices_used","support_tickets","subscription_months"]

st.markdown("""<style>
.stApp{background:linear-gradient(135deg,#0b1020,#141b31 60%,#24132f);color:#f4f6fb}
[data-testid="stSidebar"]{background:#080d19}
div[data-testid="stMetric"]{background:#ffffff10;border:1px solid #ffffff20;padding:14px;border-radius:14px}
.block-container{padding-top:1.5rem}
</style>""",unsafe_allow_html=True)

@st.cache_resource
def get_model(): return joblib.load(MODEL) if MODEL.exists() else None
def risk_name(p): return "High" if p>=.65 else ("Medium" if p>=.35 else "Low")
def actions(r,p):
    a=[]
    if r["days_since_last_active"]>=14: a.append("Send a personalized comeback message with new titles.")
    if r["watch_hours_week"]<5: a.append("Create a short watchlist based on the customer's favourite genre.")
    if r["payment_delay_days"]>=3: a.append("Send a helpful billing reminder and payment-update link.")
    if r["support_tickets"]>=2: a.append("Prioritize support follow-up and resolve the customer's issue.")
    if r["subscription_months"]<=3: a.append("Offer onboarding tips and a curated starter collection.")
    if not a: a.append("Keep recommendations fresh and consider a loyalty reward.")
    if p>=.65: a.insert(0,"HIGH PRIORITY: consider a retention offer or customer-success follow-up.")
    return a

st.sidebar.title("🎬 OTT Intelligence")
page=st.sidebar.radio("Navigation",["Overview","Customer Explorer","Predict Churn","Data & Model"])
st.sidebar.caption("Python • Machine Learning • Retention Analytics")
df=pd.read_csv(DATA)
model=get_model()
df["churn"]=pd.to_numeric(df["churn"],errors="coerce").fillna(0).astype(int)
df["Status"]=df.churn.map({0:"Active",1:"Churned"})
if model is not None:
    try: df["Risk %"]=model.predict_proba(df[FEATURES])[:,1]*100
    except Exception: df["Risk %"]=np.nan
else: df["Risk %"]=np.nan

st.title("OTT Churn Intelligence")
st.caption("Subscription analytics · churn prediction · retention actions")
st.write("Last refreshed:",datetime.now().strftime("%d %b %Y, %I:%M:%S %p"))

if page=="Overview":
    total=len(df); churn=int(df.churn.sum()); rate=100*churn/max(total,1)
    a,b,c,d=st.columns(4)
    a.metric("Total subscribers",f"{total:,}")
    b.metric("Churn rate",f"{rate:.1f}%")
    c.metric("Average monthly charge",f"₹{df.monthly_charges.mean():,.0f}")
    d.metric("High-risk customers",f"{int((df['Risk %']>=65).sum()) if df['Risk %'].notna().any() else churn:,}")
    left,right=st.columns(2)
    with left:
        st.subheader("Active vs churned")
        fig=px.pie(df,names="Status",hole=.58,color="Status",
                   color_discrete_map={"Active":"#20c997","Churned":"#ff5577"})
        fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig,use_container_width=True)
    with right:
        st.subheader("Churn by subscription plan")
        g=df.groupby("subscription_plan",as_index=False).churn.mean()
        g["Churn rate (%)"]=g.churn*100
        fig=px.bar(g,x="subscription_plan",y="Churn rate (%)",color="subscription_plan",text_auto=".1f")
        fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig,use_container_width=True)
    left,right=st.columns(2)
    with left:
        st.subheader("Weekly watch hours")
        fig=px.histogram(df,x="watch_hours_week",color="Status",barmode="overlay",opacity=.7)
        fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig,use_container_width=True)
    with right:
        st.subheader("Subscribers by favourite genre")
        g=df.favorite_genre.value_counts().rename_axis("Genre").reset_index(name="Customers")
        fig=px.bar(g,x="Genre",y="Customers",color="Customers",color_continuous_scale="Purples")
        fig.update_layout(template="plotly_dark",paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig,use_container_width=True)
    x,y,z=st.columns(3)
    x.info(f"{(df.days_since_last_active>=14).sum():,} customers inactive for 14+ days")
    y.warning(f"{(df.payment_delay_days>=3).sum():,} customers with payment delays of 3+ days")
    z.error(f"{(df.support_tickets>=2).sum():,} customers with 2+ support tickets")

elif page=="Customer Explorer":
    st.subheader("Search and filter subscribers")
    a,b,c=st.columns(3)
    plans=["All"]+sorted(df.subscription_plan.dropna().unique().tolist())
    plan=a.selectbox("Plan",plans)
    status=b.selectbox("Status",["All","Active","Churned"])
    query=c.text_input("Customer ID")
    v=df.copy()
    if plan!="All": v=v[v.subscription_plan==plan]
    if status!="All": v=v[v.Status==status]
    if query: v=v[v.customer_id.astype(str).str.contains(query,case=False,na=False)]
    cols=["customer_id","age","subscription_plan","monthly_charges","watch_hours_week","logins_per_week",
          "days_since_last_active","payment_delay_days","Status","Risk %"]
    st.write(f"{len(v):,} customers")
    st.dataframe(v[cols],use_container_width=True,hide_index=True)
    st.download_button("Download filtered CSV",v.to_csv(index=False).encode(),file_name="ott_customers_filtered.csv")

elif page=="Predict Churn":
    st.subheader("Individual churn prediction")
    if model is None: st.error("Model missing. Run the model-training notebook cell first."); st.stop()
    with st.form("predict"):
        a,b,c=st.columns(3)
        age=a.slider("Age",18,80,30); gender=b.selectbox("Gender",["Female","Male","Other"])
        plan=c.selectbox("Subscription plan",["Mobile","Basic","Standard","Premium"])
        charge=a.number_input("Monthly charge (₹)",49.,2000.,299.)
        watch=b.slider("Watch hours/week",0.,60.,8.)
        genre=c.selectbox("Favourite genre",["Drama","Comedy","Action","Thriller","Documentary","Romance","Sci-Fi"])
        logins=a.slider("Logins/week",0,30,4); inactive=b.slider("Days since last active",0,120,10)
        delay=c.slider("Payment delay days",0,30,0); devices=a.slider("Devices used",1,8,2)
        tickets=b.slider("Support tickets",0,10,0); months=c.slider("Subscription months",1,120,12)
        go=st.form_submit_button("Predict churn risk",type="primary")
    if go:
        row={"age":age,"gender":gender,"subscription_plan":plan,"monthly_charges":charge,
             "watch_hours_week":watch,"favorite_genre":genre,"logins_per_week":logins,
             "days_since_last_active":inactive,"payment_delay_days":delay,"devices_used":devices,
             "support_tickets":tickets,"subscription_months":months}
        p=float(model.predict_proba(pd.DataFrame([row])[FEATURES])[0,1])
        a,b,c=st.columns(3); a.metric("Churn probability",f"{p:.1%}")
        b.metric("Risk level",risk_name(p)); c.metric("Priority","Immediate" if p>=.65 else ("Soon" if p>=.35 else "Routine"))
        st.progress(p,text=f"Estimated churn probability: {p:.1%}")
        st.subheader("Recommended retention actions")
        for item in actions(row,p): st.write("• "+item)
        st.caption("Decision-support estimate from a demonstration model, not a guarantee.")

else:
    st.subheader("Data & Model")
    st.write("Upload a CSV with the same feature columns and a numeric churn column (0 = active, 1 = churned).")
    uploaded=st.file_uploader("Upload CSV",type=["csv"])
    if uploaded:
        new=pd.read_csv(uploaded)
        required=FEATURES+["customer_id","churn"]
        missing=[c for c in required if c not in new.columns]
        if missing: st.error("Missing columns: "+", ".join(missing))
        else:
            st.success(f"Compatible file: {len(new):,} rows")
            st.dataframe(new.head(20),use_container_width=True)
            if st.button("Replace dashboard dataset"):
                new.to_csv(DATA,index=False); st.success("Saved. Refresh the page to load updated data.")
    st.write("Model: preprocessing pipeline + Random Forest classifier")
    st.write("Input features:",", ".join(FEATURES))
    st.download_button("Download full dataset",df.drop(columns=["Status","Risk %"],errors="ignore").to_csv(index=False).encode(),
                       file_name="ott_customers.csv")
st.sidebar.divider()
st.sidebar.caption("MSc IT Data Science · Demo project")
